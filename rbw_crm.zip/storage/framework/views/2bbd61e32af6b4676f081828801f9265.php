<svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18"/>
</svg><?php /**PATH C:\Users\ihp\Documents\rbw_crm\storage\framework\views/4d59dec6a99695f6893bce42e7dafe78.blade.php ENDPATH**/ ?>