<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


    <style>
        .receipt-wrapper {
            width: 100%;
            max-width: 760px;
            margin: 20px auto;
            padding: 10px;
        }

        .total-box {
            display: flex;
            width: 380px;
            margin: 0 auto 25px;
            border: 1px solid #ccc;
        }

        .total-left {
            width: 50%;
            background: #555;
            color: #fff;
            text-align: center;
            padding: 14px;
            font-size: 22px;
            font-weight: 600;
        }

        .total-right {
            width: 50%;
            background: #fff;
            color: #a32020;
            text-align: center;
            padding: 14px;
            font-size: 34px;
            font-weight: bold;
        }

        .card {
            width: 680px;
            margin: 0 auto 18px;
            background: #fff;
            margin-bottom: 18px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, .12);
        }

        .card-body {
            padding: 24px 30px;
        }

        .row {
            display: flex;
            margin-bottom: 12px;
        }

        .label {
            width: 180px;
            color: #777;
            font-size: 18px;
        }

        .value {
            font-size: 18px;
            font-weight: 600;
            color: #111;
        }

        .footer {
            display: flex;
        }

        .amount {
            width: 50%;
            background: #b52323;
            color: #fff;
            text-align: center;
            padding: 14px;
            font-size: 24px;
            font-weight: bold;
        }

        .receipt-btn {
            width: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #fff;
            color: #b52323;
            text-decoration: none;
            font-size: 24px;
            font-weight: bold;
            border-left: 1px solid #ddd;
        }

        .receipt-btn:hover {
            background: #f8f8f8;
        }

        .receipt-btn {
            width: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;

            background: #fff;
            color: #b52323;

            text-decoration: none;
            font-size: 18px;
            font-weight: 700;

            border-left: 1px solid #ddd;
            cursor: pointer;
            transition: all .2s ease;
        }

        .receipt-btn:hover {
            background: #b52323;
            color: #fff;
        }

        .receipt-icon {
            width: 22px;
            height: 22px;
        }
    </style>

    <div class="receipt-wrapper">

        <div class="max-w-4xl mx-auto mb-4">
            <a
                href="javascript:history.back()"
                class="fi-btn fi-btn-size-md fi-btn-color-gray inline-flex items-center gap-2"
            >
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-arrow-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                <span>Back</span>
            </a>
        </div>

        <div class="total-box">

            <div class="total-left">
                Total Orders
            </div>

            <div class="total-right">
                <?php echo e($this->getOrders()->count()); ?>

            </div>

        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->getOrders(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="card">

                <div class="card-body">

                    <div class="row">
                        <div class="label">Receipt No.</div>
                        <div class="value"><?php echo e($order->id); ?></div>
                    </div>

                    <div class="row">
                        <div class="label">Date of Receipt</div>
                        <div class="value">
                            <?php echo e(\Carbon\Carbon::parse($order->booking_date)->format('d/m/Y')); ?>

                        </div>
                    </div>

                    <div class="row">
                        <div class="label">Mode</div>
                        <div class="value">
                            Online Payment
                        </div>
                    </div>

                </div>

                <div class="footer">

                    <div class="amount">
                        ₹ <?php echo e(number_format($order->price, 2)); ?>

                    </div>

                    <a href="<?php echo e(route('invoice.download', $order)); ?>" class="receipt-btn">
                        <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-arrow-down-tray'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'receipt-icon']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                        <span>INVOICE</span>
                    </a>

                </div>

            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ihp\Documents\rbw_crm\resources\views/filament/pages/orders-by-date.blade.php ENDPATH**/ ?>