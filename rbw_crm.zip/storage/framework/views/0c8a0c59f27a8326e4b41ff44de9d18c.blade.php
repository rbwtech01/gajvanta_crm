    <div class="mt-6 flex justify-center">
        <x-filament::button
            tag="a"
            href="{{ config('app.url') }}"
            color="gray"
            icon="heroicon-m-arrow-left"
        >
            Back
        </x-filament::button>
    </div>